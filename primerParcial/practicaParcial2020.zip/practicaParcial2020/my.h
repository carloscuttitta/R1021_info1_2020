#include<stdio.h>
#include<stdlib.h>

void my_toupper (char *);
int validar_correo (char *);
int imprimirNombre(char *);
int imprimirDominio(char *);
