#include<stdio.h>
#include <stdlib.h>

void ingresoDatos( int ** , int , int );
void imprimoMatriz( int ** , int , int );
void liberoMemoria(int ** , int );
