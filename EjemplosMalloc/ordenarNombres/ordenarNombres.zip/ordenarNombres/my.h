#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define TAM 256

int imprimir_nombres(char **);
int ordenar(int , char **);
