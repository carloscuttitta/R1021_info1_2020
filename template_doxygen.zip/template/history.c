/**	\file history.cpp
	\brief Historial de versiones del proyecto.
	\author Jeronimo F. Atencio (jerome5416@gmail.com)
	\date 2010.04.01
	\note 
*/

/**
	\page historyPage Historial de versiones	

	\section V1 V1 (2010.09.01) - 
		\subsection Ing. Jerónimo F. Atencio
		<ul>
		<ol>
		<li> Inicio del historial.
		</ol>
		</ul>
	
*/ 
