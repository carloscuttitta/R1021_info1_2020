#include<stdio.h>
#include<math.h>

void verificarComa(int * , char *);
float myAtof(int * , char * );
